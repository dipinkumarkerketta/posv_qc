package com.qc.dao;

import java.util.List;

import com.qc.utils.PiMproSellerTxn;

public interface PreissuanceDao {
	
			public List<PiMproSellerTxn> getMproQuestion(String txn_id);

}
