package com.qc.preissuance.serviceImpl;

import java.util.ArrayList;
import java.util.List;

import com.qc.dao.PreissuanceDao;
import com.qc.service.PreissuanceService;
import com.qc.utils.PiMproSellerTxn;

public class PreissuanceServiceImpl implements PreissuanceService{

	@Override
	public List<String> getMproQuestionDetails(String txn_id) {
		
		List<String> typeList = new ArrayList<>();
		PreissuanceDao preissuanceDao = null;
		try{
			
			List<PiMproSellerTxn> result = preissuanceDao .getMproQuestion(txn_id);
			if(result!=null&&!result.isEmpty()){
				String planCode = result.get(0).getPlancode();
				String psmLogic = result.get(0).getPsmLogic();
				String repSales = result.get(0).getRepsales();
				String ecsDetails = result.get(0).getEcsDetails();
				if(planCode!=null && "DNCCP".equalsIgnoreCase(planCode))
				{
					typeList.add("CANCER");
				}
				if(psmLogic!=null && "Y".equalsIgnoreCase(psmLogic))
				{
					typeList.add("PSM");
				}
				if(repSales!=null && "Y".equalsIgnoreCase(repSales))
				{
					typeList.add("REPLACEMENTSALE");
				}
				
				
				
			}
		}catch(Exception e)
		{
			e.printStackTrace();
		}
		
		return typeList;
		
	}

}
