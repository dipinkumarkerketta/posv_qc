package com.qc.service;

import java.util.List;

public interface PreissuanceService {

	public  List<String> getMproQuestionDetails(String txn_id);
}
