package com.qc.utils;

public class PiMproSellerTxn {
	
	private String plancode;
	private String psmLogic;
	private String repsales;
	private String ecsDetails;
	
	
	public String getEcsDetails() {
		return ecsDetails;
	}
	public void setEcsDetails(String ecsDetails) {
		this.ecsDetails = ecsDetails;
	}
	public String getPlancode() {
		return plancode;
	}
	public void setPlancode(String plancode) {
		this.plancode = plancode;
	}
	public String getPsmLogic() {
		return psmLogic;
	}
	public void setPsmLogic(String psmLogic) {
		this.psmLogic = psmLogic;
	}
	public String getRepsales() {
		return repsales;
	}
	public void setRepsales(String repsales) {
		this.repsales = repsales;
	}
	
	
	

}
