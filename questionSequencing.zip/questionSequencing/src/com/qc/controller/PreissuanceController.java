package com.qc.controller;

import java.util.List;

import com.qc.service.PreissuanceService;

public class PreissuanceController {
	
	
}
