package com.qc.daoImpl;

import java.util.List;

import com.qc.dao.PreissuanceDao;
import com.qc.utils.PiMproSellerTxn;

public class PreissuanceDaoImpl implements PreissuanceDao{

	@Override
	public List<PiMproSellerTxn> getMproQuestion(String txn_id) {

		
//		select plancode,psmlogic,repsales,ECSDETAILS from pi_seller_txn where txnid=?
		
		return null;
	}

}
